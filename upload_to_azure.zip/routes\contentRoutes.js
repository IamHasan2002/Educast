const express = require('express');
const router = express.Router();
const contentController = require('../controllers/contentController');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// Configure Multer for file upload
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, uuidv4() + path.extname(file.originalname));
    }
});

const upload = multer({ storage });

router.post('/', upload.single('media'), contentController.createPost);
router.get('/', contentController.getPosts);
router.get('/user/:userId', contentController.getUserPosts);
router.delete('/:id', contentController.deletePost);

module.exports = router;
