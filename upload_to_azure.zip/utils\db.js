const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '../data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const POSTS_FILE = path.join(DATA_DIR, 'posts.json');

// Initialize files if they don't exist
const initFiles = () => {
    if (!fs.existsSync(POSTS_FILE)) fs.writeFileSync(POSTS_FILE, JSON.stringify([], null, 2));

    // Seed Users with Admin if empty or missing
    let users = [];
    if (fs.existsSync(USERS_FILE)) {
        users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
    }

    // Check if admin exists
    const adminExists = users.some(u => u.username === 'admin');
    if (!adminExists) {
        users.push({
            id: 'admin-id',
            username: 'admin',
            password: 'admin123',
            role: 'admin',
            email: 'admin@edushare.com',
            university: 'Admin Uni',
            bio: 'System Administrator',
            createdAt: new Date().toISOString()
        });
        fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
    } else if (!fs.existsSync(USERS_FILE)) {
        // If file didn't exist but somehow code reached here (unlikely), write empty
        fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
    }
};

initFiles();

const readJSON = (file) => {
    try {
        const data = fs.readFileSync(file, 'utf8');
        return JSON.parse(data);
    } catch (err) {
        return [];
    }
};

const writeJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

module.exports = {
    getUsers: () => readJSON(USERS_FILE),
    saveUsers: (users) => writeJSON(USERS_FILE, users),
    getPosts: () => readJSON(POSTS_FILE),
    savePosts: (posts) => writeJSON(POSTS_FILE, posts),
};
