const { getPosts, savePosts } = require('../utils/db');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');

// Create Post
exports.createPost = (req, res) => {
    try {
        const { userId, content, username } = req.body; // In real app, get user from Token
        const file = req.file;

        const newPost = {
            id: uuidv4(),
            userId,
            username,
            content,
            mediaUrl: file ? `/uploads/${file.filename}` : null,
            mediaType: file ? file.mimetype : null,
            createdAt: new Date().toISOString()
        };

        const posts = getPosts();
        posts.unshift(newPost); // Add to top
        savePosts(posts);

        res.status(201).json({ message: 'Post created', post: newPost });
    } catch (err) {
        res.status(500).json({ message: 'Error creating post', error: err.message });
    }
};

// Get All Posts (with optional search)
exports.getPosts = (req, res) => {
    const { search } = req.query;
    let posts = getPosts();

    if (search) {
        const query = search.toLowerCase();
        posts = posts.filter(p =>
            (p.content && p.content.toLowerCase().includes(query)) ||
            (p.username && p.username.toLowerCase().includes(query))
        );
    }

    res.json(posts);
};

// Get User Posts
exports.getUserPosts = (req, res) => {
    const { userId } = req.params;
    const posts = getPosts().filter(p => p.userId === userId);
    res.json(posts);
};

// Delete Post
exports.deletePost = (req, res) => {
    const { id } = req.params;
    const { userId, role } = req.body; // In real app, from Token

    let posts = getPosts();
    const postIndex = posts.findIndex(p => p.id === id);

    if (postIndex === -1) {
        return res.status(404).json({ message: 'Post not found' });
    }

    const post = posts[postIndex];

    // Check permissions: Owner or Admin
    if (post.userId !== userId && role !== 'admin') {
        return res.status(403).json({ message: 'Unauthorized' });
    }

    // Delete file if exists
    if (post.mediaUrl) {
        const filePath = path.join(__dirname, '../public', post.mediaUrl);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }

    posts.splice(postIndex, 1);
    savePosts(posts);

    res.json({ message: 'Post deleted' });
};
