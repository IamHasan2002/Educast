const { getUsers, saveUsers } = require('../utils/db');
const { v4: uuidv4 } = require('uuid');

exports.register = (req, res) => {
    // Destructure all new fields
    const {
        username, password, email,
        role, university, subject,
        country, city, gender
    } = req.body;

    const users = getUsers();

    if (users.find(u => u.username === username)) {
        return res.status(400).json({ message: 'User already exists' });
    }

    const newUser = {
        id: uuidv4(),
        username,
        password, // In real app, hash this!
        email,
        role: role || 'student', // Default to student
        university: university || '',
        subject: subject || '',
        country: country || '',
        city: city || '',
        gender: gender || '',
        avatarUrl: null, // Custom avatar
        bio: '',
        createdAt: new Date().toISOString()
    };

    users.push(newUser);
    saveUsers(users);

    res.status(201).json({ message: 'User registered successfully', user: newUser });
};

exports.login = (req, res) => {
    const { username, password } = req.body;
    const users = getUsers();

    const user = users.find(u => u.username === username && u.password === password);

    if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }

    res.json({ message: 'Login successful', user });
};

// Update Profile
exports.updateProfile = (req, res) => {
    const { userId, bio, university, subject, country, city } = req.body;
    const file = req.file; // Avatar

    const users = getUsers();
    const userIndex = users.findIndex(u => u.id === userId);

    if (userIndex === -1) {
        return res.status(404).json({ message: 'User not found' });
    }

    // Update fields
    const updatedUser = { ...users[userIndex] };
    if (bio) updatedUser.bio = bio;
    if (university) updatedUser.university = university;
    if (subject) updatedUser.subject = subject;
    if (country) updatedUser.country = country;
    if (city) updatedUser.city = city;

    if (file) {
        updatedUser.avatarUrl = `/uploads/${file.filename}`;
    }

    users[userIndex] = updatedUser;
    saveUsers(users);

    res.json({ message: 'Profile updated', user: updatedUser });
};
